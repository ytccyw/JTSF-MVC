clc,clear all;
warning('off')
addpath('tproduct','dataset','CM');
dataname='NGs';
load(dataname);
clu=length(unique(Y));
n=size(X{1},1);
View=length(X);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
dataset                 lambda     alpha
proteinFold(对行标准化)	1.00E-02	1
BDGP(对列标准化)	        1.00E-03	1.00E-05
CCV	(对行标准化)	        1.00E-02  	1.00E-05
%}

for v=1:View
    X{v}=NormalizeData(X{v},1);%1是对行标准化，2是对列标准化
    X{v}=X{v}';
end
lambda=1e-2;
alpha=1e-1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l=30;
rho=1.8;
p=0.1;
mu=1e-5;
[Z] = JTSFMVC(X,l,lambda,p,alpha,mu,rho);
ZZ=zeros(n,n);
for v=1:View
    ZZ=ZZ+Z(:,:,v);
end
for repeat=1:10
    label=new_spectral_clustering(abs(ZZ), clu);
    res(repeat,:)=Clustering8Measure(Y, label);
end
res=mean(res);
fprintf('ACC: %.4f NMI: %.4f Fscore: %.4f Purity: %.4f  \n', res(1),res(2),res(3),res(6))