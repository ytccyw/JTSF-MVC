function [ ids ] = new_spectral_clustering(W, numClusters)
D = diag(1./sqrt(sum(W)+ eps));
W = D * W * D;
[U,~,~] = svd(W);
V = U(:, 1 : numClusters);
% AA = normr(V);%它有时报错所以换成7行的
AA = V ./ (sqrt(sum(V.^2, 2)) + 1e-10);
ids = kmeans(AA, numClusters, 'Replicates',15);  
end
