
function [ProcessData]=NormalizeData(X,flag)
if flag==1
    [nSmp,~] = size(X);
    for i = 1:nSmp
         ProcessData(i,:) = X(i,:) ./ max(1e-12,norm(X(i,:)));
    end
else
    [~,nSmp] = size(X);
    for i = 1:nSmp
        ProcessData(:,i) = X(:,i) ./ max(1e-12,norm(X(:,i)));
    end
end