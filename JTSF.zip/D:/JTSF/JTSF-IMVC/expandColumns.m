function output = expandColumns(inputMatrix)
    % 获取输入矩阵的行数 n 和列数 V
    [n, V] = size(inputMatrix);
    % 预分配输出结果的三维数组
    % output = zeros(n, n, V);
    % 遍历输入矩阵的每一列
    for col = 1:V
        % 取出当前列
        currentCol = inputMatrix(:, col);
        % 将当前列复制 n 份，形成 n×n 的矩阵
        output{col} = repmat(currentCol, 1, n);
    end
end    