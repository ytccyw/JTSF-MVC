clc,clear all;
warning('off')
addpath('tproduct','CM');
dataname='BDGP_fea_Per0.1';
load(dataname);
Y=truelabel{1};
clu=length(unique(Y));
flag=2;%1是对行标准化，2是对列标准化
[X, ind] = findindex(data, index,flag);
n=size(X{1},2);
View=length(X);
l=30;
H = diagonalize_columns(ind);
mu=1e-5;
rho=1.8;
lambda=1e-3;%parameter
[Z] = JTSFIMVC(X,l,lambda,mu,rho,H);
ZZ=zeros(n,n);
for v=1:View
    ZZ=ZZ+Z(:,:,v);
end
for repeat=1:10
    label=new_spectral_clustering(abs(ZZ), clu);
    res(repeat,:)=Clustering8Measure(Y, label);
end
res=mean(res);
fprintf('ACC: %f，NMI: %f，Fscore: %f，Purity: %f  \n',res(1),res(2),res(3),res(6))

