function result = diagonalize_columns(input_matrix)
    [n, v] = size(input_matrix);
    result = cell(1, v); % 初始化一个元胞数组来存储对角矩阵
    
    for col = 1:v
        % 获取当前列
        current_column = input_matrix(:, col);
        % 创建对角矩阵
        diagonal_matrix = diag(current_column);
        % 将对角矩阵存储在元胞数组中
        result{col} = diagonal_matrix;
    end
end